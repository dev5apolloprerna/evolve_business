@extends('layouts.front')
@section('opTag')
@section('title', $seo->metaTitle)

<meta name="description" content="{{ $seo->metaDescription }}" />
<meta name="keywords" content="{{ $seo->metaKeyword }}" />
{!! $seo->head !!}
{!! $seo->body !!}


@endsection

@section('content')
<section class="blog-single section section-gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 priv-head">
                        <h2 class="mb-5">Terms & Conditions</h2>






                        <p>For the purpose of these Terms and Conditions, The term "we", "us", "our" used anywhere on
                            this page shall mean Evolve Business Community	, whose registered/operational office is
                            307, Titanium One, Pakvan Cross Roads, SG Highway, Ahmedabad-380054 . "you", “your”, "user",
                            “visitor” shall mean any natural or legal person who is visiting our website and/or agreed
                            to purchase from us.

                            Your use of the website and/or purchase from us are governed by following Terms and
                            Conditions:

                            The content of the pages of this website is subject to change without notice.

                            Neither we nor any third parties provide any warranty or guarantee as to the accuracy,
                            timeliness, performance, completeness or suitability of the information and materials found
                            or offered on this website for any particular purpose. You acknowledge that such information
                            and materials may contain inaccuracies or errors and we expressly exclude liability for any
                            such inaccuracies or errors to the fullest extent permitted by law.

                            Your use of any information or materials on our website and/or product pages is entirely at
                            your own risk, for which we shall not be liable. It shall be your own responsibility to
                            ensure that any products, services or information available through our website and/or
                            product pages meet your specific requirements.

                            Our website contains material which is owned by or licensed to us. This material includes,
                            but are not limited to, the design, layout, look, appearance and graphics. Reproduction is
                            prohibited other than in accordance with the copyright notice, which forms part of these
                            terms and conditions.

                            All trademarks reproduced in our website which are not the property of, or licensed to, the
                            operator are acknowledged on the website.

                            Unauthorized use of information provided by us shall give rise to a claim for damages and/or
                            be a criminal offense.

                            From time to time our website may also include links to other websites. These links are
                            provided for your convenience to provide further information.

                            You may not create a link to our website from another website or document without Evolve Business Community  prior written consent.

                            Any dispute arising out of use of our website and/or purchase with us and/or any engagement
                            with us is subject to the laws of India .

                            We, shall be under no liability whatsoever in respect of any loss or damage arising directly
                            or indirectly out of the decline of authorization for any Transaction, on Account of the
                            Cardholder having exceeded the preset limit mutually agreed by us with our acquiring bank
                            from time to time
                        </p>


                    </div>
                </div>
            </div>
        </section>

@endsection
